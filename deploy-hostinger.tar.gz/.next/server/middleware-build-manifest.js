globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/mDeCdxpwVgSsl-5HhgRs-/_buildManifest.js",
    "static/mDeCdxpwVgSsl-5HhgRs-/_ssgManifest.js",
    "static/mDeCdxpwVgSsl-5HhgRs-/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/10qk6v6416kh8.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/3hdj40qmts5sf.js",
    "static/chunks/2-5nk792mwq2y.js",
    "static/chunks/turbopack-25v8sv2m_hva7.js"
  ]
};
