module.exports=[20544,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5BgameSlug%5D_equipos_%5BteamId%5D_page_actions_1ew3z_o.js.map