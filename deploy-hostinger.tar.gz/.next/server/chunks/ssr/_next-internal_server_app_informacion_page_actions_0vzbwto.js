module.exports=[28737,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_informacion_page_actions_0vzbwto.js.map