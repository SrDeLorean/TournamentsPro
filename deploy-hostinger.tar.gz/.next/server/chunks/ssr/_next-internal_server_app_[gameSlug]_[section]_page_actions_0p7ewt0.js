module.exports=[66870,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5BgameSlug%5D_%5Bsection%5D_page_actions_0p7ewt0.js.map