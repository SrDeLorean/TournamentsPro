module.exports=[9967,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_usuarios_page_actions_0vwz7jo.js.map