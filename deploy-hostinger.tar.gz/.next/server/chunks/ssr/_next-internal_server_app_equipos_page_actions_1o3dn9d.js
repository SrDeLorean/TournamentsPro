module.exports=[74819,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_equipos_page_actions_1o3dn9d.js.map