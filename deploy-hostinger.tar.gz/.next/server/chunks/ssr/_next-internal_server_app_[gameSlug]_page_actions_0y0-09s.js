module.exports=[53639,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5BgameSlug%5D_page_actions_0y0-09s.js.map