module.exports=[41936,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_organizaciones_page_actions_03l21wh.js.map