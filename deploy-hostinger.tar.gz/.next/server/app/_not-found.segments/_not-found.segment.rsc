1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0v0d7hmicq7b8.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/297ixabxg2cea.js"],"default"]
3:I[37457,["/_next/static/chunks/0v0d7hmicq7b8.js","/_next/static/chunks/14mrh2-p_w84d.js","/_next/static/chunks/297ixabxg2cea.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"mDeCdxpwVgSsl-5HhgRs-"}
